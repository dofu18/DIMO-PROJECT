module.exports = { content: ["./test.html"], theme: { extend: {} }, plugins: [require('@tailwindcss/line-clamp')] } 
